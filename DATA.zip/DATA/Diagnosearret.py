"""
Diagnostic : pourquoi mtbf_h / disponibilite_pct / nb_arrets / t_arret
ressortent a zero / correlation vide dans compare_ml_models.py.

Usage : python diagnose_fact_arret.py
"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import os
import warnings
import pandas as pd
from pathlib import Path
from urllib.parse import quote_plus

from dotenv import load_dotenv
from sqlalchemy import create_engine, text

warnings.filterwarnings("ignore")

_env_path = Path(__file__).parent.parent / "backend" / ".env"
load_dotenv(dotenv_path=_env_path)

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "")
DB_DW = os.getenv("DB_DW_NAME", "eleonetech_dw")


def get_engine():
    pwd = quote_plus(DB_PASSWORD)
    url = f"postgresql+psycopg2://{DB_USER}:{pwd}@{DB_HOST}:{DB_PORT}/{DB_DW}"
    return create_engine(url, pool_pre_ping=True)


def dw_query(engine, sql):
    with engine.connect() as c:
        return pd.read_sql(text(sql), c)


def main():
    print("=" * 72)
    print("  DIAGNOSTIC : indicateurs de fiabilite (fact_arret)")
    print("=" * 72)
    engine = get_engine()

    # ---- ETAPE 0 : la table existe-t-elle et est-elle accessible ? ----
    print("\n[0] La requete sur fact_arret leve-t-elle une exception ?")
    try:
        df_arret = dw_query(engine, """
            SELECT fa.equip_id,
                   t.annee_mois,
                   AVG(fa.mtbf_h) AS mtbf_h,
                   AVG(fa.disponibilite_pct) AS disponibilite_pct,
                   SUM(fa.nb_arrets) AS nb_arrets,
                   SUM(fa.t_arret) AS t_arret
            FROM fact_arret fa
            JOIN dim_temps t ON t.temps_id = fa.temps_id
            WHERE fa.equip_id IS NOT NULL
              AND t.annee_mois IS NOT NULL
            GROUP BY fa.equip_id, t.annee_mois
        """)
        print(f"    OK, aucune exception. {len(df_arret)} lignes retournees.")
    except Exception as e:
        print(f"    ECHEC ! Exception : {type(e).__name__}: {e}")
        print("    -> C'est la cause : le except Exception du script d'origine")
        print("       avale cette erreur en silence. Corrigez la requete d'abord.")
        return

    if df_arret.empty:
        print("\n[1] df_arret est VIDE (0 lignes).")
        print("    -> La table fact_arret ne contient aucune ligne exploitable,")
        print("       ou la jointure avec dim_temps ne matche rien.")
        print("    Verifiez :")
        print("      SELECT COUNT(*) FROM fact_arret;")
        print("      SELECT COUNT(*) FROM fact_arret WHERE equip_id IS NOT NULL;")
        print("      SELECT COUNT(*) FROM fact_arret fa JOIN dim_temps t")
        print("        ON t.temps_id = fa.temps_id;  -- teste juste la jointure")
        return

    # ---- ETAPE 1 : les colonnes sources sont-elles elles-memes vides/nulles ? ----
    print(f"\n[1] df_arret contient {len(df_arret)} lignes. Verification des valeurs sources :")
    for col in ["mtbf_h", "disponibilite_pct", "nb_arrets", "t_arret"]:
        n_null = df_arret[col].isna().sum()
        n_zero = (df_arret[col] == 0).sum()
        print(f"    {col}: {n_null} NULL / {len(df_arret)} | {n_zero} valeurs a zero | "
              f"min={df_arret[col].min()} max={df_arret[col].max()} moyenne={df_arret[col].mean():.4f}")
    if all(df_arret[c].fillna(0).eq(0).all() for c in ["mtbf_h", "disponibilite_pct", "nb_arrets", "t_arret"]):
        print("    -> TOUTES les valeurs sont a 0 ou NULL directement a la source (fact_arret).")
        print("       Ce n'est pas un bug de jointure : fact_arret n'est pas alimentee")
        print("       correctement en amont (verifiez transformation.py / load_dwtest.py).")
        return
    print("    -> Les donnees source ne sont PAS toutes nulles : le probleme vient")
    print("       probablement de la jointure avec le jeu principal (etape 2).")

    # ---- ETAPE 2 : la jointure equip_id + annee_mois matche-t-elle ? ----
    print("\n[2] Test du taux de correspondance de la jointure (equip_id, annee_mois)")
    df_raw = dw_query(engine, """
        SELECT fi.equip_id, t.annee_mois
        FROM fact_intervention fi
        JOIN dim_temps t ON t.temps_id = fi.temps_id
        WHERE fi.equip_id IS NOT NULL AND t.annee_mois IS NOT NULL
        GROUP BY fi.equip_id, t.annee_mois
    """)
    print(f"    Combinaisons (equip_id, annee_mois) cote fact_intervention : {len(df_raw)}")
    print(f"    Combinaisons (equip_id, annee_mois) cote fact_arret        : {len(df_arret)}")

    print(f"    Types : df_raw.equip_id={df_raw['equip_id'].dtype} | df_arret.equip_id={df_arret['equip_id'].dtype}")
    print(f"    Types : df_raw.annee_mois={df_raw['annee_mois'].dtype} | df_arret.annee_mois={df_arret['annee_mois'].dtype}")

    merged = df_raw.merge(df_arret, on=["equip_id", "annee_mois"], how="left", indicator=True)
    match_rate = (merged["_merge"] == "both").mean()
    print(f"    Taux de correspondance de la jointure : {match_rate:.1%}")

    if match_rate < 0.05:
        print("    -> Quasiment aucune correspondance (<5%). Causes probables :")
        print("       - equip_id de types differents (ex: '12' texte vs 12 entier)")
        print("       - annee_mois de formats differents (ex: '2025-01' vs '2025-1' vs Timestamp)")
        print("       - fact_arret alimentee sur une plage de dates disjointe de fact_intervention")
        sample_raw = set(df_raw['equip_id'].astype(str).unique()[:5])
        sample_arret = set(df_arret['equip_id'].astype(str).unique()[:5])
        print(f"    Exemples equip_id (intervention) : {sample_raw}")
        print(f"    Exemples equip_id (arret)        : {sample_arret}")
    elif match_rate < 0.5:
        print("    -> Correspondance partielle : fact_arret ne couvre qu'une partie du parc")
        print("       ou des mois. Les autres lignes sont remplies a 0 par fillna(0),")
        print("       ce qui dilue fortement le signal (beaucoup de zeros artificiels).")
    else:
        print("    -> Bonne correspondance. Le probleme vient possiblement d'ailleurs")
        print("       (ex: variance trop faible malgre des valeurs non nulles).")


if __name__ == "__main__":
    main()